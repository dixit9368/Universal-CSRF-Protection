<?php
/*
Plugin Name: Universal CSRF Protection
Description: Automatically adds nonce-based CSRF protection to all WordPress forms using the POST method.
Version: 1.0
Author: Surabhi Rank
*/

// Prevent direct access to the plugin file
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// Function to add nonce field to all forms with POST method
function ucp_add_nonce_field( $content ) {
    if ( strpos( $content, '<form' ) !== false && strpos( $content, 'method="post"' ) !== false ) {
        $nonce_field = wp_nonce_field( 'ucp_csrf_protection_nonce', '_ucp_nonce', true, false );
        $content = preg_replace( '/<form([^>]+)>/', '<form$1>' . $nonce_field, $content );
    }
    return $content;
}

// Automatically add nonce to content, widgets, and shortcodes
add_filter( 'the_content', 'ucp_add_nonce_field' );
add_filter( 'widget_text', 'ucp_add_nonce_field' );
add_filter( 'widget_text_content', 'ucp_add_nonce_field' );
add_filter( 'do_shortcode_tag', 'ucp_add_nonce_field' );

// Verify nonce for all POST requests
function ucp_verify_nonce() {
    if ( $_SERVER['REQUEST_METHOD'] === 'POST' ) {
        if ( ! isset( $_POST['_ucp_nonce'] ) || ! wp_verify_nonce( $_POST['_ucp_nonce'], 'ucp_csrf_protection_nonce' ) ) {
            wp_die( 'CSRF validation failed. Please try again.', 'Error', array( 'response' => 403 ) );
        }
    }
}
add_action( 'wp', 'ucp_verify_nonce' );

// Add nonce to Contact Form 7 forms
function ucp_add_nonce_to_cf7( $form ) {
    return ucp_add_nonce_field( $form );
}
add_filter( 'wpcf7_form_elements', 'ucp_add_nonce_to_cf7' );
